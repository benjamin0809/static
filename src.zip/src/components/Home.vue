<template>
  <div style="height: 400px">
    Hollo World
  </div>
</template>
  <script>
export default {
  name: "helleWorld",
  props: {
  },
  data() {
    return {

    };
  },
  methods: {
    compare(data, oldData, compareProps) {
      
    }
  },
  watch: {
    oldData(newVal) {

    },
    data(newVal) {
      
    }
  }
};
</script>