<template>
  <div style="height: 400px">
    产品清单
  </div>
</template>
  <script>
export default {
  name: "Products",
  props: {
  },
  data() {
    return {

    };
  },
  methods: {
    compare(data, oldData, compareProps) {
      
    }
  },
  watch: {
    oldData(newVal) {

    },
    data(newVal) {
      
    }
  }
};
</script>