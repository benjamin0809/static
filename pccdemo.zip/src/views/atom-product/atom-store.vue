<template>
  <div style="height: 400px;text-align: center;">
    <h2>细分市场原子货架</h2>
    <div class="market-box">
      <div class="market"
           :class="index === 0 ? 'selected' : ''"
           v-for="(item, index) in data.市场分类"
           :key="index">{{ item }}</div>
    </div>
    <div class="product-box">
      <div class="category-title">产品分类</div>
      <div class="category"
           :class="index === 0 ? 'selected' : ''"
           v-for="(item, index) in data.产品分类"
           :key="index">{{ item }}</div>
    </div>
    <div class="input-box">
      <el-input placeholder="请输入内容">
        <i slot="prefix"
           class="el-input__icon el-icon-search"></i>
      </el-input>
    </div>
  </div>
</template>
  <script>
import { storedata } from './data'
export default {
  name: "Products",
  props: {
  },
  data () {
    return {
      data: storedata,
    };
  },
  methods: {
    compare (data, oldData, compareProps) {

    }
  },
  watch: {
    oldData (newVal) {

    },
    data (newVal) {

    }
  }
};
</script>
<style lang="scss" scoped>
.market-box {
  display: flex;
  .selected {
    text-decoration: underline;
    color: blue;
  }
  .market {
    margin-bottom: 10px;
    padding: 0px 10px;
    font-size: 20px;
    font-weight: bold;
    border-right: 2px solid #ccc;
    &:last-child {
      border-right: none;
    }
    &:first-child {
      padding-left: 0px;
    }
  }
}
.product-box {
  display: flex;
  font-size: 18px;
  .category-title {
    font-weight: bold;
  }
  .category {
    margin-left: 8px;
    &:hover {
      cursor: pointer;
      color: blue;
    }
  }
}
.input-box {
  margin: 12px 0;
  width: 200px;
}
</style>