<template>
  <div id="app">
    <header>中国移动</header>
    <router-view></router-view>
  </div>
</template>
<script>

export default {
  name: "app",
  components: {
  },
  methods: {
  },
  data() {
    return {};
  },
};
</script>