import Vue from 'vue'
import VueRouter from 'vue-router'
import App from '../App.vue'
import Product from '../views/atom-product/index.vue'
import AtomStore from '../views/atom-product/atom-store.vue'
import Package from '../views/atom-product/product-package.vue'
import ProductList from '../views/atom-product/product-package.vue'
import ProductQuery from '../views/atom-product/product-query.vue'

Vue.use(VueRouter)
const routes = [
  {
    path: '/',
    component: App,
    children: []
  },
  {
      path: '/products',// 产品列表首页
      component: Product,
    },
    {
      path: '/store', // 原子货架
      component: AtomStore,
    },
    {
      path: '/package', // 产品封装
      component: Package,
    },
    {
      path: '/product-list', // 产品清单
      component: ProductList,
    },
    {
      path: '/product-query', // 产品目录查询
      component: ProductQuery,
    }
]
export default new VueRouter({
  mode: 'hash',
  routes
})